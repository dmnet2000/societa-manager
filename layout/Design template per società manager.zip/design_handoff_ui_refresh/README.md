# Handoff: Design Refresh — Società Manager

## Overview
Design references for a UI refresh of `societa-manager` (Next.js + Prisma + Supabase, gestionale polisportiva). Covers a login screen with club logo, an expandable sidebar submenu, a reusable component set, and a design-token reference — all grounded in the actual repo (`app/globals.css`, `app/NavBar.tsx`).

## About the Design Files
The `.dc.html` files in this bundle are **design references**, not production code. They are static HTML/CSS prototypes showing intended look, layout and states. The task is to **recreate these designs in the app's real environment** — Next.js App Router, React Server/Client Components, CSS Modules — following the codebase's existing patterns. Do not copy the HTML/inline-style markup verbatim into `.tsx` files.

## Fidelity
**High-fidelity.** Colors, spacing, radii and type sizes are pulled directly from `app/globals.css` — exact values, not approximations. Copy text is illustrative placeholder data (athlete names, dates) and should be replaced with real data bindings.

## Screens / Views

### 1. Login (0a desktop / 0b mobile) — `Mockup Schermate.dc.html`
- Centered card (380px desktop / 300px mobile) on a navy-to-blue gradient background (`--color-navy` → `--color-button-bg`)
- Club logo (`assets/logo-mogliano-volley.png`), centered, fixed height (64px desktop / 56px mobile), `margin: 0 auto`
- Title "Mogliano Volley" (20px/900 desktop, 18px mobile) + subtitle "Volleyball Club" (12px, `--color-text-secondary`)
- Email + password fields (bordered, `--radius-sm`, `--space-3` padding), "Password dimenticata?" link right-aligned, full-width primary button below
- **Real target**: `app/(auth)/accedi/` — has its own `accedi.module.css`, not the shared `.pagina-form`/`.riquadro-form` globals. Add the logo there (reuse `logo-mogliano-volley.png` or better, the Admin-configurable logo via `lib/storage/logo.ts`, Story 7.2).

### 2. Dashboard (1a/1b), Orari Palestre (2a/2b), Presenze (3a/3b), Certificati Medici (4a/4b)
Standard shell: navy sidebar (220px, desktop) with nav items, `active` item highlighted with `--color-button-bg` background; mobile uses a topbar (☰ + title) instead. Content area: `--space-8` padding, stat boxes in a 2-col grid on dashboard, tables (`--color-surface-alt` header row) elsewhere.
- **Real target**: existing route groups per screen map below.

### 3. Sidebar submenu ("Amministrazione")
Expandable nav item with a `▾` indicator, revealing 3 indented sub-items (Impostazioni, Utenti e Ruoli, Logo Applicazione) with a left border (`rgba(255,255,255,0.15)`) and reduced opacity (0.85) text.
- **Real target**: `app/NavBar.tsx` + `NavBar.module.css`. Needs a `useState` for expand/collapse (`aria-expanded` on the toggle), and `lib/auth/voci-navigazione.ts` extended to support nested children (currently a flat `{ href, label }` array).

## Interactions & Behavior
- Sidebar submenu toggles open/closed on click (not yet wired in the mock — static "open" state shown for review)
- All other elements (buttons, links, table rows) are static in the mock; standard hover states apply per the token guide

## Design Tokens
See `Guida Design Tokens.dc.html` for the full visual reference. Source of truth is `app/globals.css` (already in the repo — do not redefine):
- Colors: `--color-navy #312682`, `--color-button-bg #006da6`, `--color-primary #00a3e0`, `--color-primary-hover #0086bd`, `--color-magenta #e6007c`, `--color-surface #fff`, `--color-surface-alt #e4f5fd`, `--color-border #bfe4f5`, `--color-text-primary #101820`, `--color-text-secondary #46586b`, `--color-success #256029` / `--color-success-bg #dff2e1`, `--color-warning #9a4a08` / `--color-warning-bg #fce9ce`, `--color-danger #a81818` / `--color-danger-bg #fbe3e3`
- Radii: `--radius-sm 6px`, `--radius-md 8px`
- Spacing scale: `--space-1..8` = 4/8/12/16/20/24/32px
- Font: system stack (`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif`) — no custom font
- Breakpoint: `880px` (desktop sidebar vs. mobile drawer)
- Card shadow: `0 1px 3px rgba(16,24,32,0.08)`

## Assets
- `assets/logo-mogliano-volley.png` — club logo, copied from the repo (`_bmad-output/planning-artifacts/ux-designs/ux-societa-manager-2026-07-22/imports/logo-mogliano-volley.png`), 437×469px, not square

## Files
- `Mockup Schermate.dc.html` — all screen mockups (login, dashboard, orari, presenze, certificati), desktop + mobile
- `Componenti Riusabili.dc.html` — component library (buttons, badges, form fields, cards, table, sidebar w/ submenu, modal)
- `Guida Design Tokens.dc.html` — full token reference (colors, type, spacing, radius, layout/breakpoints)
- `Guida Implementazione.dc.html` — implementation notes mapping each mock to real repo files, plus a pre-merge checklist

## Screen map (mock → repo)
| Mock | Repo file(s) |
|---|---|
| Login | `app/(auth)/accedi/` |
| Sidebar/NavBar | `app/NavBar.tsx`, `app/NavBar.module.css`, `lib/auth/voci-navigazione.ts` |
| Design tokens | `app/globals.css` |
| Orari Palestre | `app/(orari-palestre)/*` |
| Presenze | `app/(presenze)/presenze/*` |
| Certificati Medici | `app/(certificati-medici)/*` |
